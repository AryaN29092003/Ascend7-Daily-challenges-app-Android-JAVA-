package com.example.madprofinal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ViewFlipper;

import com.bumptech.glide.Glide;

public class day_7 extends AppCompatActivity {
    ViewFlipper carousel;
    TextView textview,textview2,texttask1,texttask1des,txttask3,txttask3des;
    Button Btncomp,Btnskip,Btnnext,Btnprev,Btncomp1,Btnskip1,Btncomp3,Btnskip3;
    ImageView image,outfit,pet;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day7);
        textview= findViewById(R.id.textView);
        textview2= findViewById(R.id.textView2);
        texttask1= findViewById(R.id.txttask1);
        texttask1des= findViewById(R.id.txttask1des);
        Btncomp= findViewById(R.id.btncompleted);
        Btnskip= findViewById(R.id.btnskip);
        Btncomp1= findViewById(R.id.btncompleted1);
        Btnskip1= findViewById(R.id.btnskip1);
        carousel= findViewById(R.id.view_flipper);
        Btnnext= findViewById(R.id.next_button);
        Btnprev= findViewById(R.id.prev_button);
        txttask3= findViewById(R.id.txttask3);
        txttask3des= findViewById(R.id.txttask3des);
        Btncomp3= findViewById(R.id.btncompleted3);
        Btnskip3= findViewById(R.id.btnskip3);
        image= findViewById(R.id.reconnect);
        outfit= findViewById(R.id.outfit);
        pet= findViewById(R.id.pet);

        Glide.with(this)
                .load(R.drawable.reconnect)
                .into(image);
        Glide.with(this)
                .load(R.drawable.outfit)
                .into(outfit);
        Glide.with(this)
                .load(R.drawable.pet)
                .into(pet);

        Btncomp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Btncomp.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view3));
                Btnskip.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view4));
            }
        });

        Btnskip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Btncomp.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view4));
                Btnskip.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view3));
            }
        });

        Btncomp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Btncomp1.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view3));
                Btnskip1.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view4));
            }
        });

        Btnskip1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Btncomp1.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view4));
                Btnskip1.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view3));
            }
        });

        Btncomp3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Btncomp3.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view3));
                Btnskip3.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view4));
            }
        });

        Btnskip3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Btncomp3.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view4));
                Btnskip3.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.rounded_corner_view3));
            }
        });

        Btnprev.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        // It is used to set the in and out
                        // animation of View flipper.
                        carousel.setInAnimation(getApplicationContext(),
                                R.anim.slide_right);
                        carousel.setOutAnimation(getApplicationContext(),
                                R.anim.slide_left);

                        // It shows previous item.
                        carousel.showPrevious();
                    }
                });

        Btnnext.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        // It is used to set the in and out
                        // animation of View flipper.
                        carousel.setInAnimation(getApplicationContext(),
                                R.anim.slide_left);
                        carousel.setOutAnimation(getApplicationContext(),
                                R.anim.slide_right);

                        // It shows next item.
                        carousel.showNext();
                    }
                });


        textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textview2.setVisibility(View.VISIBLE);
                Btnskip.setVisibility(View.VISIBLE);
                Btncomp.setVisibility(View.VISIBLE);
                ObjectAnimator animation = ObjectAnimator.ofFloat(textview2, "translationY", 440f);
                animation.setDuration(1100);
                animation.start();
                ObjectAnimator animation1 = ObjectAnimator.ofFloat(Btncomp, "translationY", 800f);
                animation1.setDuration(1600);
                animation1.start();
                ObjectAnimator animation2 = ObjectAnimator.ofFloat(Btnskip, "translationY", 1000f);
                animation2.setDuration(2200);
                animation2.start();
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        image.setVisibility(View.VISIBLE);
                    }
                }, 2000);
            }
        });
        textview2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                image.setVisibility(View.INVISIBLE);
                ObjectAnimator animation = ObjectAnimator.ofFloat(textview2, "translationY", 00f);
                animation.setDuration(1000);
                animation.start();
                ObjectAnimator animation1 = ObjectAnimator.ofFloat(Btncomp, "translationY", 00f);
                animation1.setDuration(1500);
                animation1.start();
                ObjectAnimator animation2 = ObjectAnimator.ofFloat(Btnskip, "translationY", 00f);
                animation2.setDuration(2000);
                animation2.start();

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        textview2.setVisibility(View.INVISIBLE);
                        Btnskip.setVisibility(View.INVISIBLE);
                        Btncomp.setVisibility(View.INVISIBLE);

                        image.setVisibility(View.INVISIBLE);
                    }
                }, 2000);

            }
        });
        texttask1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                texttask1des.setVisibility(View.VISIBLE);
                Btnskip1.setVisibility(View.VISIBLE);
                Btncomp1.setVisibility(View.VISIBLE);
                ObjectAnimator animation = ObjectAnimator.ofFloat(texttask1des, "translationY", 440f);
                animation.setDuration(1100);
                animation.start();
                ObjectAnimator animation1 = ObjectAnimator.ofFloat(Btncomp1, "translationY", 800f);
                animation1.setDuration(1600);
                animation1.start();
                ObjectAnimator animation2 = ObjectAnimator.ofFloat(Btnskip1, "translationY", 1000f);
                animation2.setDuration(2200);
                animation2.start();
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        outfit.setVisibility(View.VISIBLE);
                    }
                }, 2000);
            }
        });
        texttask1des.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                outfit.setVisibility(View.INVISIBLE);
                ObjectAnimator animation = ObjectAnimator.ofFloat(texttask1des, "translationY", 00f);
                animation.setDuration(1000);
                animation.start();
                ObjectAnimator animation1 = ObjectAnimator.ofFloat(Btncomp1, "translationY", 00f);
                animation1.setDuration(1500);
                animation1.start();
                ObjectAnimator animation2 = ObjectAnimator.ofFloat(Btnskip1, "translationY", 00f);
                animation2.setDuration(2000);
                animation2.start();
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        texttask1des.setVisibility(View.INVISIBLE);
                        Btnskip1.setVisibility(View.INVISIBLE);
                        Btncomp1.setVisibility(View.INVISIBLE);
                    }
                }, 2000);


            }
        });
        txttask3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txttask3des.setVisibility(View.VISIBLE);
                Btnskip3.setVisibility(View.VISIBLE);
                Btncomp3.setVisibility(View.VISIBLE);
                ObjectAnimator animation = ObjectAnimator.ofFloat(txttask3des, "translationY", 440f);
                animation.setDuration(1100);
                animation.start();
                ObjectAnimator animation1 = ObjectAnimator.ofFloat(Btncomp3, "translationY", 800f);
                animation1.setDuration(1600);
                animation1.start();
                ObjectAnimator animation2 = ObjectAnimator.ofFloat(Btnskip3, "translationY", 1000f);
                animation2.setDuration(2200);
                animation2.start();
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        pet.setVisibility(View.VISIBLE);
                    }
                }, 2000);
            }
        });
        txttask3des.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pet.setVisibility(View.INVISIBLE);
                ObjectAnimator animation = ObjectAnimator.ofFloat(txttask3des, "translationY", 00f);
                animation.setDuration(1000);
                animation.start();
                ObjectAnimator animation1 = ObjectAnimator.ofFloat(Btncomp3, "translationY", 00f);
                animation1.setDuration(1500);
                animation1.start();
                ObjectAnimator animation2 = ObjectAnimator.ofFloat(Btnskip3, "translationY", 00f);
                animation2.setDuration(2000);
                animation2.start();
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        txttask3des.setVisibility(View.INVISIBLE);
                        Btnskip3.setVisibility(View.INVISIBLE);
                        Btncomp3.setVisibility(View.INVISIBLE);
                    }
                }, 2000);



            }
        });
    }
}