package com.example.madprofinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class signup extends AppCompatActivity {

    private FirebaseAuth auth;
    EditText EdtName,EdtEmail,EdtPass;
    ImageView ImgBtnSignup2;
    TextView Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        auth= FirebaseAuth.getInstance();
        EdtName= findViewById(R.id.edtname);
        EdtPass= findViewById(R.id.edtpass);
        EdtEmail= findViewById(R.id.edtemail);
        ImgBtnSignup2= findViewById(R.id.imgbtnsignup2);
        Login= findViewById(R.id.txtlogin);

        ImgBtnSignup2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username= EdtName.getText().toString().trim();
                String usermail= EdtEmail.getText().toString().trim();
                String userpass= EdtPass.getText().toString().trim();

                if (username.isEmpty()){
                    EdtName.setError(" Username can't be empty");
                }
                if (usermail.isEmpty()) {
                    EdtEmail.setError(" User Email can't be empty");
                }
                if (userpass.isEmpty()){
                    EdtPass.setError("user password can't be empty");
                } else{
                    auth.createUserWithEmailAndPassword(usermail, userpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if (task.isSuccessful()){
                                Toast.makeText(getApplicationContext(),"SignUp successful",Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), login.class));
                            }else {
                                Toast.makeText(signup.this, "SignUp Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }


            }
        });
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), login.class));
            }
        });
    }
}