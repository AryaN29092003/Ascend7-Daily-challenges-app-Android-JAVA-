package com.example.madprofinal;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class days_all_tasks extends AppCompatActivity {
    Button Btnday1,Btnday2,Btnday3,Btnday4,Btnday5,Btnday6,Btnday7;
    ImageButton Btnhome;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_days_all_tasks);
        Btnday1= findViewById(R.id.btnday1);
        Btnday2= findViewById(R.id.btnday2);
        Btnday3= findViewById(R.id.btnday3);
        Btnday4= findViewById(R.id.btnday4);
        Btnday5= findViewById(R.id.btnday5);
        Btnday6= findViewById(R.id.btnday6);
        Btnday7= findViewById(R.id.btnday7);
        Btnhome= findViewById(R.id.btnhome);

        Btnhome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
            }
        });


        Btnday1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), day_1.class));
            }
        });
        Btnday2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), Day_2.class));
            }
        });
        Btnday3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), day_3.class));
            }
        });
        Btnday4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), day_4.class));
            }
        });
        Btnday5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), day_5.class));
            }
        });
        Btnday6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), day_6.class));
            }
        });
        Btnday7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), day_7.class));
            }
        });


    }
}